-- name: YOU ARE A \\#00ff00\\SHIT.
-- description: YOU ARE A \\#00ff00\\SHIT.\\#ffffff\\\n\nYou are a certified shit if you fall off a slide.

local shit = get_texture_info("YOU_ARE_A_SHIT")
local shit_sound = audio_stream_load("YOU_ARE_A_SHIT_SOUND.mp3")
local opacity = 0
local played_sound = false
local opacity_changed = false

local function update()
    if opacity == 255 then
        played_sound = false
        if not played_sound then
            audio_stream_play(shit_sound, true, 2)
            played_sound = true
        end
    end
    if opacity > 0 then
        opacity = opacity - 1.75
    end
    if opacity <= 0 then
        opacity_changed = false
    end
end

---@param m MarioState
local function mario_update(m)
    if m.playerIndex ~= 0 then return end
    if gNetworkPlayers[0].currCourseNum == COURSE_PSS then
        --if m.pos.y < (-5000) then
        if m.floor.type == SURFACE_DEATH_PLANE then
            if not opacity_changed then
                opacity = 255
                opacity_changed = true
            end
        end
    end
    if gNetworkPlayers[0].currCourseNum == COURSE_TTM then
        if gNetworkPlayers[0].currAreaIndex == 2 then
            --if m.pos.y < (-2000) then
            if m.floor.type == SURFACE_DEATH_PLANE then
                if not opacity_changed then
                    opacity = 255
                    opacity_changed = true
                end
            end
        end
    end
    if gNetworkPlayers[0].currCourseNum == COURSE_CCM then
        if gNetworkPlayers[0].currAreaIndex == 2 then
            if m.floor.type == SURFACE_DEATH_PLANE then
                if not opacity_changed then
                    opacity = 255
                    opacity_changed = true
                end
            end
        end
    end
end

local function on_hud_render()
    local screenH = djui_hud_get_screen_height()
    local screenW = djui_hud_get_screen_width()
    djui_hud_set_color(255, 255, 255, opacity)
    djui_hud_render_texture(shit, 0, 0, screenW / 512, screenH / 512)
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_event(HOOK_UPDATE, update)