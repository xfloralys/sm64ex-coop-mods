-- name: Weather Cycle
-- description: \\#00ffff\\Weather Cycle\\#ffffff\\\n\nThis mod features rain, occasionally. Not only does it introduce cosmetic changes, it also alters Mario's physics ever so slightly since water is slippery. I might add more weather types in the future, but for now have this.\n\nMod made by \\#2b0013\\Floralys\\#ffffff\\ and special thanks to \\#ec7731\\ Agent X\\#ffffff\\ for helping with fixing an annoying glitch that disabled warps.

local particle = get_texture_info("rain") -- i spent approximatively 30 seconds on that texture
gGlobalSyncTable.is_raining = false
gGlobalSyncTable.timer = 0
local rain_start = 619200
local rain_end = 1382400
local compatible = true

-- Which levels rain does not wish to visit
local not_compatible = {
    COURSE_CCM, COURSE_HMC, COURSE_VCUTM, COURSE_SL, COURSE_TTC, COURSE_COTMC, COURSE_SSL, COURSE_LLL, COURSE_BITFS, COURSE_PSS, COURSE_SA
}

-- Respecfully, GO FUCK YOURSELVES. I hate EVERY SINGLE ONE OF YOU. Your lives are NOTHING. You serve ZERO PURPOSE. You should kill yourselves, NOW!
local ignored_surfaces = {
    SURFACE_BURNING, SURFACE_QUICKSAND, SURFACE_INSTANT_QUICKSAND, SURFACE_INSTANT_MOVING_QUICKSAND, SURFACE_DEEP_MOVING_QUICKSAND, SURFACE_INSTANT_QUICKSAND, SURFACE_DEEP_QUICKSAND, SURFACE_SHALLOW_MOVING_QUICKSAND,
    SURFACE_SHALLOW_QUICKSAND, SURFACE_WARP, SURFACE_LOOK_UP_WARP, SURFACE_WOBBLING_WARP, SURFACE_INSTANT_WARP_1B, SURFACE_INSTANT_WARP_1C, SURFACE_INSTANT_WARP_1D, SURFACE_INSTANT_WARP_1E
}

-- The Agent X trick to improve performance
local djui_hud_get_screen_width = djui_hud_get_screen_width
local djui_hud_get_screen_height = djui_hud_get_screen_height
local djui_hud_set_resolution = djui_hud_set_resolution
local djui_hud_set_color = djui_hud_set_color
local djui_hud_set_render_behind_hud = djui_hud_set_render_behind_hud
local djui_hud_render_rect = djui_hud_render_rect
local set_override_skybox = set_override_skybox
local djui_hud_render_texture = djui_hud_render_texture
local play_sound = play_sound
local get_skybox = get_skybox
local network_is_server = network_is_server
--local djui_hud_print_text = djui_hud_print_text

local function on_hud_render()
    local resx = djui_hud_get_screen_width()
    local resy = djui_hud_get_screen_height()
    djui_hud_set_resolution(RESOLUTION_N64)

    if gGlobalSyncTable.is_raining and compatible then -- If it's raining and you're in a level the rain is willing to visit
        --djui_hud_set_color(255, 255, 255, 255)
        --djui_hud_print_text("Britain", (resx/10), (resy/50), 1)
        djui_hud_set_color(64, 64, 64, 150)
        djui_hud_set_render_behind_hud(true)
        djui_hud_render_rect(0, 0, 1960, 1080)
        djui_hud_set_color(128, 255, 255, math.random(0,255))
        set_override_skybox(4)
        if gMarioStates[0].pos.y >= (gMarioStates[0].waterLevel - 350) then
            for i = 0, 3000 do
                djui_hud_render_texture(particle, math.random(resx), math.random(resy), 0.005, 0.03)
            end
        end
    else -- If it's sunny or the rain doesn't want to come to you then nothing changes lmao
        local skybox = get_skybox()
        set_override_skybox(skybox)
        return
    end

    --djui_hud_print_text(tostring(gGlobalSyncTable.timer), 10, 150, 0.1)
end

---@param m MarioState
local function mario_update(m)
    if network_is_server() then -- Timer only increases for the host - ensures rain syncing
        gGlobalSyncTable.timer = gGlobalSyncTable.timer + 1
    end
    if gGlobalSyncTable.timer == rain_start then -- also ensures rain syncing
        gGlobalSyncTable.is_raining = true
    end
    if gGlobalSyncTable.timer == rain_end then
        gGlobalSyncTable.is_raining = false
        gGlobalSyncTable.timer = 0
    end
    for i = 0, 11 do -- checks if you're in one of those despised levels
        if gNetworkPlayers[0].currCourseNum == not_compatible[i] then
            compatible = false
            return
        else
            if gNetworkPlayers[0].currLevelNum == LEVEL_CASTLE then
                compatible = false
                return
            else
                if gNetworkPlayers[0].currCourseNum == COURSE_TTM and gNetworkPlayers[0].currAreaIndex == 2 then
                    compatible = false
                    return
                else
                    compatible = true
                end
            end
        end
    end
    if gGlobalSyncTable.is_raining and compatible then -- Water footsteps, rain sounds, slippery floor (caution), water particles and fire extinguishment
        if m.action == ACT_WALKING then
            if gGlobalSyncTable.timer % 5 == 0 then
                play_sound(SOUND_OBJ_WALKING_WATER, m.marioObj.header.gfx.cameraToObject)
                spawn_sync_object(id_bhvWaterDropletSplash, E_MODEL_SMALL_WATER_SPLASH, m.pos.x, m.pos.y, m.pos.z, function()end)
            end
        end
        if m.action == ACT_BURNING_GROUND or m.action == ACT_BURNING_FALL or m.action == ACT_BURNING_JUMP then
            m.action = ACT_WALKING
            play_sound(SOUND_GENERAL_FLAME_OUT, m.marioObj.header.gfx.cameraToObject)
        end
        play_sound(SOUND_ENV_WATERFALL1, m.marioObj.header.gfx.cameraToObject)
    end
end

---@param m MarioState
local function before_mario_update(m)
    if gGlobalSyncTable.is_raining and compatible then
        if gNetworkPlayers[0].currLevelNum == LEVEL_BITS and gNetworkPlayers[0].currAreaIndex == 1 then
            return
        end
        for i = 0, 16 do
            if m.floor.type ~= ignored_surfaces[i] then
                if m.floor.type ~= SURFACE_DEATH_PLANE and m.floor.type ~= SURFACE_VERTICAL_WIND then -- YOU TOO. You thought I'd forget? NO. I HATE YOU. KILL YOURSELVES.
                    m.floor.type = SURFACE_SLIPPERY
                end
            end
        end
    end
end

local function toggle(msg)
    msg = string.lower(msg)
    if network_is_moderator() or network_is_server() then
        if msg == "on" then -- /toggle on (rain)
            gGlobalSyncTable.is_raining = true
            gGlobalSyncTable.timer = 619201
        end
        if msg == "off" then -- /toggle off (no rain)
            gGlobalSyncTable.is_raining = false
            gGlobalSyncTable.timer = 0
        end
        djui_chat_message_create("Rain has been toggled.")
        return true
    else
        djui_chat_message_create("You do not have permission to run this command.")
        return true
    end
end

local function softlock(msg) -- /respawn (you die. like, seriously. you die.)
    gMarioStates[0].health = 0
    gMarioStates[0].numLives = gMarioStates[0].numLives + 1
    return true
end

hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_event(HOOK_BEFORE_MARIO_UPDATE, before_mario_update)
hook_chat_command("toggle", "-\\#00ffff\\ [Weather Cycle]\\#ffffff\\ [on/off] Turn rain on and off using this command.", toggle)
hook_chat_command("respawn", "- \\#00ffff\\[Weather Cycle]\\#ffffff\\ If you ever end up permanently stuck while sliding, use this. Or if you just want to die...", softlock)