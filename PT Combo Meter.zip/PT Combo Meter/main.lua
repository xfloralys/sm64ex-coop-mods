-- name: PT Combo Meter
-- description: \\#ff0000\\Pizza Tower Combo Meter \\#ffffff\\\n\nThis mod introduces Pizza Tower's combo meter. The higher the combo, the more coins you get. Speaking of which, coins increase the remaining time before the combo resets back to 0. The more coins you get, the higher you're ranked upon grabbing a star!\n\nUnfortunately, some enemies don't count towards the combo. That's an issue we are aware of and weren't able to fix.\n\nMod by \\#00ff00\\SCBx3\\#ffffff\\ and \\#2b0013\\Floralys\\#ffffff\\.

local meter = get_texture_info("combo")

local djui_hud_set_resolution = djui_hud_set_resolution
local djui_hud_set_font = djui_hud_set_font
local djui_hud_set_color = djui_hud_set_color
local djui_hud_print_text = djui_hud_print_text

local combo = 0
local delay = 0
local is_combo = false
local started = false
local prevHealth = 0
local timer = 200
local x_pos = 0
local rewarded_coins = 0
local star_get = false
local rect_timer = 0
local coins = 0

local bhvs = {
    id_bhvGoomba, id_bhvKoopa, id_bhvBoo, id_bhvBobomb, id_bhvChuckya, id_bhvEnemyLakitu, id_bhvFlyGuy, id_bhvFlyguyFlame,
    id_bhvSmallWhomp, id_bhvMontyMole, id_bhvMrI, id_bhvPokey, id_bhvPokeyBodyPart, id_bhvPiranhaPlant, id_bhvFirePiranhaPlant, 
    id_bhvSmallPiranhaFlame, id_bhvScuttlebug, id_bhvBooInCastle, id_bhvSwoop, id_bhvWhompKingBoss, id_bhvSnufit, id_bhvBalconyBigBoo,
    id_bhvKingBobomb, id_bhvThwomp2, id_bhvThwomp, id_bhvSkeeter, id_bhvGhostHuntBoo, id_bhvPokeyBodyPart, id_bhvSmallBully,
    id_bhvBigBully, id_bhvBigChillBully, id_bhvBigChillBully, id_bhvBigBullyWithMinions, id_bhvSpindrift, id_bhvMoneybag
}

local blueCoinBhvs = {
    id_bhvBlueCoinJumping, id_bhvBlueCoinNumber, id_bhvBlueCoinSliding, id_bhvHiddenBlueCoin, id_bhvMovingBlueCoin, id_bhvMrIBlueCoin
}

local function hud_render()
    if combo > 9 and combo < 100 then
        x_pos = 45
    else
        if combo >= 100 then
            x_pos = 40
        else
            x_pos = 50
        end
    end

    djui_hud_render_texture(meter, 0, 0, 1, 1)
    djui_hud_set_resolution(RESOLUTION_N64)
    djui_hud_set_font(FONT_HUD)
    djui_hud_set_color(145, 64, 237, 255)
    djui_hud_print_text(tostring(combo), x_pos, 50, 1.35)

    if combo > 0 then
        djui_hud_set_color(0, 255, 0, 255)
        djui_hud_print_text(tostring(timer), 68, 39, 0.35)
    end

    djui_hud_set_font(FONT_TINY)

    if combo >= 1 and combo < 5 then
        djui_hud_set_color(255, 255, 255, 255)
        djui_hud_print_text("Lame...", 50, 120, 1)
        rewarded_coins = 1
    end
    if combo >= 5 and combo < 10 then
        djui_hud_set_color(239, 227, 133, 255)
        djui_hud_print_text("Cheesy", 50, 120, 1)
        rewarded_coins = 3
    end
    if combo >= 10 and combo < 15 then
        djui_hud_set_color(158, 117, 160, 255)
        djui_hud_print_text("Not bad but not great either", 15, 120, 1)
        rewarded_coins = 3
    end
    if combo >= 15 and combo < 20 then
        djui_hud_set_color(112, 222, 84, 255)
        djui_hud_print_text("Getting somewhere!", 25, 120, 1)
        rewarded_coins = 8
    end
    if combo >= 20 and combo < 25 then
        djui_hud_set_color(215, 143, 16, 255)
        djui_hud_print_text("Nice, :) Good job", 25, 120, 1)
        rewarded_coins = 8
    end
    if combo >= 25 and combo < 30 then
        djui_hud_set_color(243, 205, 171, 255)
        djui_hud_print_text("Cheflike", 47, 120, 1)
        rewarded_coins = 16
    end
    if combo >= 30 and combo < 35 then
        djui_hud_set_color(200, 33, 10, 255)
        djui_hud_print_text("Brutal!", 47, 120, 1)
        rewarded_coins = 16
    end
    if combo >= 35 and combo < 40 then
        djui_hud_set_color(206, 34, 1, 255)
        djui_hud_print_text("Evil", 50, 120, 1)
        rewarded_coins = 24
    end
    if combo >= 40 and combo < 45 then
        djui_hud_set_color(85, 0, 14, 255)
        djui_hud_print_text("Unclean", 47, 120, 1)
        rewarded_coins = 24
    end
    if combo >= 45 and combo < 50 then
        djui_hud_set_color(220, 50, 0, 255)
        djui_hud_print_text("Disturbing", 45, 120, 1)
        rewarded_coins = 32
    end
    if combo >= 50 and combo < 55 then
        djui_hud_set_color(224, 137, 84, 255)
        djui_hud_print_text("Twisted", 47, 120, 1)
        rewarded_coins = 32
    end
    if combo >= 55 and combo < 60 then
        djui_hud_set_color(131, 0, 0, 255)
        djui_hud_print_text("Psychotic", 45, 120, 1)
        rewarded_coins = 64
    end
    if combo >= 60 and combo < 65 then
        djui_hud_set_color(0, 0, 0, 255)
        djui_hud_print_text("Ill-willed", 45, 120, 1)
        rewarded_coins = 64
    end
    if combo >= 65 and combo < 70 then
        djui_hud_set_color(174, 48, 0, 255)
        djui_hud_print_text("Crushing", 45, 120, 1)
        rewarded_coins = 128
    end
    if combo >= 70 and combo < 75 then
        djui_hud_set_color(213, 1, 148, 255)
        djui_hud_print_text("Funny!", 50, 120, 1)
        rewarded_coins = 128
    end
    if combo >= 75 then
        djui_hud_set_color(47, 87, 136, 255)
        djui_hud_print_text("Unfunny", 47, 120, 1)
        rewarded_coins = 192
    end

    if star_get then
        djui_hud_set_color(0, 0, 0, 128)
        djui_hud_render_rect(187, 200, 75, 25)

        djui_hud_set_font(FONT_NORMAL)

        if coins >= 0 and coins < 40 then
            djui_hud_set_color(48, 80, 120, 255)
            djui_hud_print_text("D-RANK", 203, 198, 0.6)
            djui_hud_print_text("Awful", 216, 213, 0.4)
        end
        if coins >= 40 and coins < 65 then
            djui_hud_set_color(96, 208, 72, 255)
            djui_hud_print_text("C-RANK", 203, 198, 0.6)
            djui_hud_print_text("Bad", 219, 213, 0.4)
        end
        if coins >= 65 and coins < 85 then
            djui_hud_set_color(48, 168, 248, 255)
            djui_hud_print_text("B-RANK", 203, 198, 0.6)
            djui_hud_print_text("Ok", 221, 213, 0.4)
        end
        if coins >= 85 and coins < 100 then
            djui_hud_set_color(248, 0, 0, 255)
            djui_hud_print_text("A-RANK", 203, 198, 0.6)
            djui_hud_print_text("Nice!", 216, 213, 0.4)
        end
        if coins >= 100 and combo < 10 then
            djui_hud_set_color(224, 144, 0, 255)
            djui_hud_print_text("S-RANK", 203, 198, 0.6)
            djui_hud_print_text("Perfect", 213, 213, 0.4)
        end
        if coins >= 100 and combo >= 10 then
            djui_hud_set_color(152, 80, 248, 255)
            djui_hud_print_text("M-RANK", 203, 198, 0.6)
            djui_hud_print_text("Awesome!", 209, 213, 0.4)
        end
        
        if rect_timer >= 150 then
            star_get = false
            rect_timer = 0
        end
    end
end

---@param interactor MarioState
---@param interactee Object
---@param interactType InteractionType
---@param interactValue boolean
local function interact(interactor, interactee, interactType, interactValue)
    if (interactor.playerIndex ~= 0) then
        return
    end
    for i, j in ipairs(bhvs) do
        if (get_id_from_behavior(interactee.behavior) == bhvs[i]) then
            if (get_id_from_behavior(interactee.behavior) == id_bhvBobomb) or (get_id_from_behavior(interactee.behavior) == id_bhvKingBobomb) or (get_id_from_behavior(interactee.behavior) == id_bhvChuckya) then
                if (interactor.action == ACT_THROWING) or (interactor.action == ACT_HEAVY_THROW) then
                    is_combo = true
                end
            else
                is_combo = true
            end
        end
    end
    if (get_id_from_behavior(interactee.behavior) == id_bhvYellowCoin) then
        timer = timer + 10
    end
    if (get_id_from_behavior(interactee.behavior) == id_bhvRedCoin) then
        timer = timer + 20
    end
    for k, l in ipairs(blueCoinBhvs) do
        if (get_id_from_behavior(interactee.behavior) == blueCoinBhvs[k]) then
            timer = timer + 50
        end
    end
    if (interactType == INTERACT_STAR_OR_KEY) then
        star_get = true
    end
end

---@param m MarioState
local function mario_update(m)
    if m.playerIndex ~= 0 then return end
    if not started then
        prevHealth = 2500
        started = true
    end
    if star_get then
        rect_timer = rect_timer + 1
    end
    if combo > 0 then
        timer = timer - 1
    else
        timer = 200
    end
    if timer <= 0 then
        for i = 0, (rewarded_coins - 1) do
            spawn_sync_object(id_bhvYellowCoin, E_MODEL_YELLOW_COIN, m.pos.x, m.pos.y, m.pos.z, function()end)
        end

        combo = 0
        timer = 200
        rewarded_coins = 0
    end
    if m.health < prevHealth then
        combo = 0
        prevHealth = m.health
    end
    if m.health > prevHealth then
        prevHealth = m.health
    end
    if is_combo then
        delay = delay + 1
        if delay >= 10 then
            combo = combo + 1
            delay = 0
            timer = 200
            is_combo = false
        end
    end
    coins = m.numCoins
end

hook_event(HOOK_ON_INTERACT, interact)
hook_event(HOOK_MARIO_UPDATE, mario_update)
hook_event(HOOK_ON_HUD_RENDER, hud_render)