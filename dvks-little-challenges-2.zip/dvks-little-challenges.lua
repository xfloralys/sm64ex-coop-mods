-- name: Dvk's Little Challenges
-- description: \\#2b0013\\Dvk's Little Challenges\\#ffffff\\\n\nYou are given a task to complete, and everytime you complete them, you earn points. The amount of points may vary depending on difficulty.

if mod_storage_load("Points") == nil then
	mod_storage_save("Points", "0")
end

local points = tonumber(mod_storage_load("Points"))

local course = nil
local course_names = {
    "Bob-Omb Battlefield", "Whomp's Fortress",
    "Jolly Roger Bay", "Cool, Cool Mountain",
    "Big Boo's Haunt", "Hazy Maze Cave",
    "Lethal Lava Land", "Shifting Sand Land",
    "Dire Dire Docks", "Snowman's Land",
    "Wet-Dry World", "Tall Tall Mountain",
    "Tiny-Huge Island", "Tick Tock Clock",
    "Rainbow Ride", "The Princess's Secret Slide",
    "The Secret Aquarium", "Wing Mario over the Rainbow",
    "Tower of the Wing Cap", "Cavern of the Metal Cap",
    "Vanish Cap under the Moat", "Bowser in the Dark World",
    "Bowser in the Fire Sea", "Bowser in the Sky"
}

local mario_course_check = 0

local type = nil
local challenge_types = {
    "Stars", "Coins", "Lives", "Star 1", "Star 2", "Star 3", "Star 4", "Star 5", "Star 6", "the 100 Coins Star"
}

local starsRequired = 0
local coinsRequired = 0
local livesRequired = 0
local stars = 0
local wantedStar = 0
local multipleStarsPossible = nil
local maxcoinnumber = 0
local number = nil
local scale = 0
local starId = 0

local challenge = ''
local created_challenge = false

local function create_challenge()
    course = course_names[math.random(1,24)]
    if course == course_names[16] or course == course_names[17] or course == course_names[18] or course == course_names[19] or course == course_names[20] or course == course_names[21] or course == course_names[22] or course == course_names[23] or course == course_names[24] and multipleStarsPossible ~= false then
        multipleStarsPossible = false
        maxcoinnumber = 30
        --djui_chat_message_create("test")
    end
    if multipleStarsPossible == nil then
        multipleStarsPossible = true
        maxcoinnumber = 100
    end
    if multipleStarsPossible then
        type = challenge_types[math.random(1,10)]
    else
        type = challenge_types[math.random(2,4)]
    end
    if type == challenge_types[1] then
        starsRequired = math.random(1,7)
        number = starsRequired
    elseif type == challenge_types[2] then
        coinsRequired = math.random(1,maxcoinnumber)
        number = coinsRequired
    elseif type == challenge_types[3] then
        livesRequired = math.random(1,40)
        number = livesRequired
    end
    if number ~= nil and type ~= challenge_types[3] then
        challenge = 'Get ' .. tostring(number) .. " " .. tostring(type) .. " in " .. tostring(course)
    end
    if number == nil and type ~= challenge_types[3] then
        challenge = 'Get ' .. tostring(type) .. " in " .. tostring(course)
    end
    if type == challenge_types[3] then
        challenge = 'Get ' .. tostring(number) .. " " .. tostring(type)
    end
    if type == challenge_types[4] then
        wantedStar = 0
    end
    if type == challenge_types[5] then
        wantedStar = 1
    end
    if type == challenge_types[6] then
        wantedStar = 2
    end
    if type == challenge_types[7] then
        wantedStar = 3
    end
    if type == challenge_types[8] then
        wantedStar = 4
    end
    if type == challenge_types[9] then
        wantedStar = 5
    end
    if type == challenge_types[10] then
        wantedStar = 6
    end

    if course == course_names[1] then
        mario_course_check = COURSE_BOB
    elseif course == course_names[2] then
        mario_course_check = COURSE_WF
    elseif course == course_names[3] then
        mario_course_check = COURSE_JRB
    elseif course == course_names[4] then
        mario_course_check = COURSE_CCM
    elseif course == course_names[5] then
        mario_course_check = COURSE_BBH
    elseif course == course_names[6] then
        mario_course_check = COURSE_HMC
    elseif course == course_names[7] then
        mario_course_check = COURSE_LLL
    elseif course == course_names[8] then
        mario_course_check = COURSE_SSL
    elseif course == course_names[9] then
        mario_course_check = COURSE_DDD
    elseif course == course_names[10] then
        mario_course_check = COURSE_SL
    elseif course == course_names[11] then
        mario_course_check = COURSE_WDW
    elseif course == course_names[12] then
        mario_course_check = COURSE_TTM
    elseif course == course_names[13] then
        mario_course_check = COURSE_THI
    elseif course == course_names[14] then
        mario_course_check = COURSE_TTC
    elseif course == course_names[15] then
        mario_course_check = COURSE_RR
    elseif course == course_names[16] then
        mario_course_check = COURSE_PSS
    elseif course == course_names[17] then
        mario_course_check = COURSE_SA
    elseif course == course_names[18] then
        mario_course_check = COURSE_WMOTR
    elseif course == course_names[19] then
        mario_course_check = COURSE_TOTWC
    elseif course == course_names[20] then
        mario_course_check = COURSE_COTMC
    elseif course == course_names[21] then
        mario_course_check = COURSE_VCUTM
    elseif course == course_names[22] then
        mario_course_check = COURSE_BITDW
    elseif course == course_names[23] then
        mario_course_check = COURSE_BITFS
    elseif course == course_names[24] then
        mario_course_check = COURSE_BITS
    end
end

---@param interactor MarioState
---@param interactee Object
---@param interactType InteractionType
---@param interactValue boolean
local function star_check(interactor, interactee, interactType, interactValue)
    if (interactor.playerIndex ~= 0) or (interactType ~= INTERACT_STAR_OR_KEY) then
        return
    end
    starId = (interactee.oBehParams >> 24) & 0x1F
end

---@param m MarioState
local function challenge_check(m)
    if m.playerIndex ~= 0 then return end
    if gNetworkPlayers[0].currCourseNum == mario_course_check then
        --djui_chat_message_create("yeah good level man")
        if type == challenge_types[1] then
            stars = save_file_get_course_star_count(get_current_save_file_num() - 1, gNetworkPlayers[0].currCourseNum - 1)
            --djui_chat_message_create(tostring(stars))
            if stars >= starsRequired then
                if starsRequired <= 3 then
                    starsRequired = 999
                    points = points + 4
                elseif starsRequired > 3 and starsRequired <= 6 then
                    starsRequired = 999
                    points = points + 8
                elseif starsRequired == 7 then
                    starsRequired = 999
                    points = points + 15
                end
                created_challenge = false
                challenge = ''
                number = nil
                play_sound(SOUND_GENERAL2_STAR_APPEARS, m.marioObj.header.gfx.cameraToObject)
                play_sound(SOUND_MARIO_HERE_WE_GO, m.marioObj.header.gfx.cameraToObject)
            end
        end
        if type == challenge_types[2] then
            if m.numCoins >= coinsRequired then
                if coinsRequired <= 65 then
                    coinsRequired = 999
                    points = points + 1
                elseif coinsRequired > 65 and coinsRequired <= 85 then
                    coinsRequired = 999
                    points = points + 2
                elseif coinsRequired > 85 and coinsRequired <= 100 then
                    coinsRequired = 999
                    points = points + 4
                end
                created_challenge = false
                number = nil
                challenge = ''
                play_sound(SOUND_GENERAL2_STAR_APPEARS, m.marioObj.header.gfx.cameraToObject)
                play_sound(SOUND_MARIO_HERE_WE_GO, m.marioObj.header.gfx.cameraToObject)
            end
        end
        if type == challenge_types[4] or type == challenge_types[5] or type == challenge_types[6] or type == challenge_types[7] or type == challenge_types[8] or type == challenge_types[9] then
            if starId == wantedStar then
                points = points + 2
                created_challenge = false
                number = nil
                challenge = ''
                play_sound(SOUND_GENERAL2_STAR_APPEARS, m.marioObj.header.gfx.cameraToObject)
                play_sound(SOUND_MARIO_HERE_WE_GO, m.marioObj.header.gfx.cameraToObject)
            end
        end
        if type == challenge_types[10] then
            if starId == wantedStar then
                points = points + 2
                created_challenge = false
                number = nil
                challenge = ''
                play_sound(SOUND_GENERAL2_STAR_APPEARS, m.marioObj.header.gfx.cameraToObject)
                play_sound(SOUND_MARIO_HERE_WE_GO, m.marioObj.header.gfx.cameraToObject)
            end
        end
    end
    if type == challenge_types[3] then
        if m.numLives >= livesRequired then
            if livesRequired <= 8 then
                livesRequired = 999
                if m.numStars >= 120 then
                    points = points + 1
                else
                    points = points + 2
                end
            elseif livesRequired > 8 and livesRequired <= 15 then
                livesRequired = 999
                if m.numStars >= 120 then
                    points = points + 1
                else
                    points = points + 4
                end
            elseif livesRequired > 15 and livesRequired <= 30 then
                livesRequired = 999
                if m.numStars >= 120 then
                    points = points + 2
                else
                    points = points + 7
                end
            elseif livesRequired > 30 and livesRequired <= 40 then
                livesRequired = 999
                if m.numStars >= 120 then
                    points = points + 3
                else
                    points = points + 12
                end
            end
            created_challenge = false
            number = nil
            challenge = ''
            play_sound(SOUND_GENERAL2_STAR_APPEARS, m.marioObj.header.gfx.cameraToObject)
            play_sound(SOUND_MARIO_HERE_WE_GO, m.marioObj.header.gfx.cameraToObject)
        end
    end
    mod_storage_save("Points", tostring(points))
    gPlayerSyncTable[0].score = points
end

local function on_hud_render()
    if not created_challenge then
        create_challenge()
        created_challenge = true
    end
    if points < 10 then
        scale = 45
    elseif points < 100 then
        scale = 40
    elseif points < 1000 then
        scale = 35
    elseif points < 10000 then
        scale = 30
    end
    djui_hud_set_resolution(RESOLUTION_N64)
    djui_hud_set_font(FONT_MENU)
    djui_hud_set_color(255,255,0,255)
    djui_hud_print_text("Current Task :", 10, 170, 0.25)
    djui_hud_set_color(255,255,255,255)
    djui_hud_print_text(challenge, 10, 187.5, 0.17)
    djui_hud_set_color(0,255,0,255)
    djui_hud_print_text("Total Points :", 10, 200, 0.25)
    djui_hud_set_font(FONT_HUD)
    djui_hud_print_text(tostring(points), scale, 217.5, 1)
end

local function reset_points(msg)
    points = 0
    mod_storage_save("Points", tostring(points))
    gPlayerSyncTable[0].score = points
    djui_chat_message_create("Your score has been reset.")
    return true
end

function server_update()
    for i = 0, MAX_PLAYERS - 1 do
        local m = gMarioStates[i]
        if not gNetworkPlayers[m.playerIndex].connected then return end
        network_player_set_description(gNetworkPlayers[m.playerIndex], tostring(gPlayerSyncTable[m.playerIndex].score), 0, 255, 0, 255)
    end
end

hook_event(HOOK_ON_HUD_RENDER, on_hud_render)
hook_event(HOOK_MARIO_UPDATE, challenge_check)
hook_event(HOOK_ON_INTERACT, star_check)
hook_event(HOOK_MARIO_UPDATE, server_update)
hook_chat_command("reset", "- \\#2b0013\\[Dvk's Little Challenges]\\#ffffff\\ Resets your total points. Be careful when using this, there's no way to recover them.", reset_points)

for i = 0, MAX_PLAYERS - 1 do
    gPlayerSyncTable[i].score = tonumber(mod_storage_load("Points")) or 0
    if i == 0 then
        gPlayerSyncTable[0].score = tonumber(mod_storage_load("Points")) or 0
    end
end